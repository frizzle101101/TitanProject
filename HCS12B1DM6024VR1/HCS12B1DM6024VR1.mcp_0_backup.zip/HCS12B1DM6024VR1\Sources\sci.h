#include <hidef.h>      /* common defines and macros */
#include "derivative.h"      /* derivative-specific definitions */
#include "myUtils.h"


#define BaudRate 38400
#define ClockRate 8000000
#define Divider (ClockRate/16/BaudRate)
#define BUFFER_SIZE 255

void initSCI(void);
void putcSCI( char cx );
void putsSCI( char *str );
char getcSCI( void );
char SCIdequeue(void);



   