 #include "servo.h"
 
 /*

output(us)=10*in(degrees) + 600us
600us is 0 degrees
1050us is 45 degrees
1500us is 90 degrees
1950us is 135 degrees
2400us is 180 degrees
*/
//do not go above 180 degrees or below 0 degrees
unsigned int dutycycle;
 
 void timer_servo_INIT(void){
//the prescaler was set to 8 so 1us = 1 OC Value
  TSCR2 = PRESCALER_VAL; 	// set prescaler to 8, no interrupt
  TSCR1	= TSCR_INIT;    	// enable TCNT, fast timer flag clear, freeze
  
  //TCTL1 = ZERO;           // initilize the upper bits of TCTL register to zero so it does nothing 
  TCTL2 = TCTL2_LOW;        // initilize timer channel 2 to low
  
 
  TC2	= TCNT + dutycycle;	// preset TC2 for first OC event
  TIE = ENABLE_TIMER_RTI;   // enable interrupts for timer channel 2
 	                       
	SET_BITS(TIOS, TIOS_IOS2_MASK);	// ready to go - enable TC2 as OC

}

void degree2time(unsigned int degrees){
  
  dutycycle = (RC_gain*degrees) + offset_time;
  
  
}
interrupt 10 void ISR_usDelay(void){
   
    if(TCTL2 == TCTL2_LOW){               // if the TCTL2 is low the it has completed the high toggle
    TC2 = TCNT + (RC_PERIOD - dutycycle); // rearm the OC register for low time
    TCTL2 = TCTL2_HIGH;                   // TCTL2 to high so it starts the period as high in the next interrupt
    } 
    
    else if(TCTL2 == TCTL2_HIGH){   // if the TCTL2 is high the it has completed the 20ms period or the low toggle 
    TC2 = TCNT + dutycycle;		      // rearm the OC register for high time
    TCTL2 = TCTL2_LOW;              // TCTL2 to low so it completes the 20ms period in the next interrupt
    }
    else{}

}