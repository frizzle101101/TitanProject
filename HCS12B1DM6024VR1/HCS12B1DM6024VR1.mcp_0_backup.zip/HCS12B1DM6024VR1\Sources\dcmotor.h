#include "derivative.h"      /* derivative-specific definitions */
#include "myUtils.h"


#define EIGHT_BIT_MODE 0x00
#define PWM_RESET 0x00
#define PWM_ECLK 0x00
#define PRESCALE_0 0x00
#define SA_DIVIDE_2 0x01
#define PERIOD_22KHZ_LEFT_ALINGED 182U
#define PWM_DTY_10 18U
#define PWM_DTY_60 108U
#define PWM_DTY_75 135U
#define PERIOD_22KHZ_CENTER_ALINGED 182U
#define SB_DIVIDE_128 0x60
#define PERIOD_300HZ_LEFT_ALINGED 208U
#define RTI_PERIOD 0x49 // Sets RTI period to 5.12mS (Look up tabel in slides)
#define LOW_CMD 80
#define HI_CMD 190

void DC_motor_init(void);
void DC_motor_drive(int fb, int lr);