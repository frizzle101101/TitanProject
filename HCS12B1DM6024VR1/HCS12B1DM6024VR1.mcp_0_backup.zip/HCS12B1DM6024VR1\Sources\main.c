#include <hidef.h>      /* common defines and macros */
#include "derivative.h"      /* derivative-specific definitions */
#include "lcd.h"
#include "adc.h"
#include "dcmotor.h"
#include "myUtils.h"
#include "sci.h"
#include "servo.h"
#include "spi.h"
#include "stepper.h"
#include "timer.h"

unsigned char cc = 0;
int rev = 0;
unsigned int pwmctr = 0;
char scic[4];
void main(void) {
  /* put your own code here */
  ms_timer_init();
  initLCD();
  //initADC();
  DC_motor_init();
  initSCI();
  //timer_servo_INIT();
  //InitSPI(SCK_LOW_SAMPLE_RISE,MSB_FIRST,MASTER,INTERRUPT_OFF,SPI_ON,OUTPUT_BUFFER_ON,MODE_FAULT_OFF,0x02);
  
  //writeDacSpi(VOLTAGE_REF,VREF_3_8V,SUB);
  
  //stepper_init();
  
  LCDprintf("Helelo");
  //LCDcmd(LCD_CLEAR_MASK);

	EnableInterrupts;

  

	
  
  for(;;) {
    //unsigned int analog = getAnalog();
    //unsigned int degrees = map(analog, 0, 255, 0, 180);
    
    //int i = 0;
    //putcSCI('a');
#if 0
    int i = 0;
    for(i; i < 4; i++) {
      scic[i] = SCIdequeue();//check for control input
    }
    if(!scic[0]) {
      //get event type: axis or button
      //get axis or button number changed
      //get value of change
      char event = scic[0];
      char abid = scic[1];
      int value = scic[2]+scic[3];//fix this line
      if(event == 1) {
        //button 
        
      } else if(event == 2) {
        //axis
        if(abid == 0 || abid == 1) {
          //change drive acording to axis and value  
           
        } else if(abid == 2 || abid == 3){
          //change camera angle
        }
      }
    }
#endif

    //writeDacSpi(DATA,cc++,SUB);
    //LCDprintf("%d", pwmctr);
    //Delay_ms(1000);
    //LCDclear();

        
    //degree2time(degrees);
    _FEED_COP(); /* feeds the dog */
  } /* loop forever */
  /* please make sure that you never leave main */
}