#include "dcmotor.h"

unsigned int firstEdgeTCH0, firstEdgeTCH1;
unsigned int edge0, edge1, period0, period1;

void DC_motor_init(void) {
  
  
  //Initilize PWM ports 4 & 5
  PWMCTL = EIGHT_BIT_MODE;                                                              // 8-bit mode 
  PWMPRCLK = PWM_ECLK;                                                                  // Counts E-clock directly
  PWMSCLA = SA_DIVIDE_2;                                                                // Set the SA divisor to devide the clock by 2 (Refer to table 8.4 in textbook)
  PWMCLK |= (PWMCLK_PCLK4_MASK | PWMCLK_PCLK5_MASK);                                    // Select clock SA as the clock source for PWM port 4 & 5 
  PWMPOL |= (PWMPOL_PPOL4_MASK | PWMPOL_PPOL5_MASK);                                    // Sets both PWM port 4 & 5 to output high at the start of a period (Positave Polarity), by setting the bits
  PWMCAE &= LOW(PWMCAE_CAE0_MASK);                                                      // Select left - aligned mode for PWM port 4
  PWMCAE &= LOW(PWMCAE_CAE1_MASK);                                                      // Select left - aligned mode for PWM port 5
  PWMPER4 = PERIOD_22KHZ_LEFT_ALINGED;                                                  // Sets period value to 22KHz
  PWMPER5 = PERIOD_22KHZ_LEFT_ALINGED;
  PWMDTY4 = 80;                                                                 // Duty cycle (75% of the PWM frequency for PWM channel 4)
  PWMDTY5 = 80;                                                                 // Duty cycle (75% of the PWM frequency for PWM channel 5)
  PWMCNT4 = PWM_RESET;                                                                  // Reset PWM4 & PWM5 counter
  PWMCNT5 = PWM_RESET;
  
  
  SET_BITS(DDRB, (DDRB_BIT0_MASK|DDRB_BIT1_MASK|DDRB_BIT2_MASK|DDRB_BIT3_MASK));         // configures PORTB 0,1,2,3 to outputs
  
  SET_BITS(PORTB,(PORTB_BIT0_MASK|PORTB_BIT3_MASK));                                     // writes a 1 to bits 0 and 3
  CLR_BITS(PORTB,(PORTB_BIT1_MASK|PORTB_BIT2_MASK));                                     // writes a 0 to bits 1 and 2
  
  
  
  PWME |= (PWME_PWME4_MASK|PWME_PWME5_MASK);                                            // Enable the PWM0 and PWM1 ports
  
  
}
void DC_motor_drive(int fb, int lr){
  PWMDTY4 = 0;                                                                 // Duty cycle (75% of the PWM frequency for PWM channel 4)
  PWMDTY5 = 0;
}
interrupt VectorNumber_Vtimch0 void TIMCH0handler (void){
  if(firstEdgeTCH0 != 1) {
    edge0 	= TC0;  		/* save the first captured edge and clear C0F flag */
    firstEdgeTCH0 = 1;
  }else{
    period0 	= TC0 - edge0;	/* calculate the period as the difference between edge timestamps */
    firstEdgeTCH0 = 0;
  }
}
interrupt VectorNumber_Vtimch1 void TIMCH1handler (void){
  if(firstEdgeTCH1 != 1) {
    edge1 	= TC1;  		/* save the first captured edge and clear C0F flag */
    firstEdgeTCH1 = 1;
  }else{
    period1 	= TC1 - edge1;	/* calculate the period as the difference between edge timestamps */
    firstEdgeTCH1 = 0;
  }
}