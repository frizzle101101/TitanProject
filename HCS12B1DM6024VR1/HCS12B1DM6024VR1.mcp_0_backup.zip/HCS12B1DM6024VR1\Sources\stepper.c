#include "stepper.h"

unsigned char stepper_speed;
unsigned char rti_count;
unsigned char stepper_array[] = {MOTOR_A,MOTOR_AC,MOTOR_C,MOTOR_BC,MOTOR_B,MOTOR_BD,MOTOR_D,MOTOR_AD};        // array with the different outputs required for the stepper motor.
unsigned char state;                                                                                          // array index
char step_type;                                                                                               // full step or halfstep, forwards or backwards
char limit_switch;
int no_check_LS;
int step_count;
int step_count_synced;


void stepper_init(void) {
  
  rti_count = 1;
  stepper_speed = 2;
  state = 0;
  step_type = -2;
  limit_switch = 0; 
  
  CLR_BITS(DDRAD,(DDRAD_DDRAD6_MASK|DDRAD_DDRAD7_MASK));//set pin ad6,ad7 as inputs                   
  
  SET_BITS(DDRP,DDRP_DDRP3_MASK); // enables the stepper motor by enabeling PP3 to an output
  SET_BITS(PTP,PTP_PTP3_MASK); // sets PP3 to a high
  
  SET_BITS(DDRT, (DDRT_DDRT7_MASK|DDRT_DDRT6_MASK|DDRT_DDRT5_MASK|DDRT_DDRT4_MASK));// configures Port T 4,5,6,7 to be outputs
  
  FORCE_BITS(PTT,PORT_T_WRITE_MASK,stepper_array[state]);
  
  //prepare rti registers
  RTICTL = RTI_PERIOD;                  // Set RTI period 
  SET_BITS(COPCTL, COPCTL_RSBCK_MASK);  // Freeze RTI during BDM active
  CRGFLG = CRGFLG_RTIF_MASK;            // Clear any possibly pending RTI interrupts
  SET_BITS(CRGINT, CRGINT_RTIE_MASK); //enable rti
}
int getStepperPosition(){
  if(step_count_synced)
    return(step_count);
  else
    return(-1);//error stepper not synced
}

interrupt VectorNumber_Vrti void RTIhandler (void) {
	
	
    CRGFLG = CRGFLG_RTIF_MASK;// Clear any possibly pending RTI interrupts
    limit_switch = (PTAD & LIMIT_SWITCH_MASK);// equates the value of PAD6 and PAD7 to limit_switch
   
   if(limit_switch != 0) { // checks if either of the limit switches has been pressed
    step_type = (step_type * REVERSE);
    no_check_LS = 1;//signal to not check the next rti for button pressed
    step_count_synced = 1;//button pressed not count is in sync
    step_count = 0;
    limit_switch = 0;
   } 
   else 
   {
  	 if (rti_count < stepper_speed) {  // counter that devides the speed of the motor.
  	  rti_count++;       
  	 }
  	 else{
  	  
  	  state += step_type;
  	  state &= STEPPER_MASK;
  	  
  	  FORCE_BITS(PTT,PORT_T_WRITE_MASK,stepper_array[state]);
  	  step_count++;
  	  rti_count = 1; 
  	 }
   }
}

