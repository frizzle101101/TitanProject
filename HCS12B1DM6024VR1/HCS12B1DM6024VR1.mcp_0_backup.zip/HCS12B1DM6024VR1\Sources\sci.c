#include "sci.h"

int sciBufCount = 0;
char buffer[BUFFER_SIZE];
   
void initSCI(void) 
{
  
 SCISR1 = 0;          //reset status register to default flag states
 SCIBD = Divider;      //configures Baud rate at set value
 SCICR1 = 0;          //First sci control register     set to 0b80 for loop select enable
 SCICR2 = 0;          //Second controll register 
 SET_BITS(SCICR2, (SCICR2_RE_MASK | SCICR2_TE_MASK)); //enable transmit and recieve lines
 SET_BITS(SCICR2, SCISR1_RDRF_MASK);       //enables reciever full interrupts
 
}

void putcSCI( char cx ) {
  while (!(SCISR1 & SCISR1_TDRE_MASK));
  SCIDRL = cx;
}


void putsSCI( char *str ) {
  while( *str )
    putcSCI( *str++);
}


char getcSCI( void ) {
  while(!(SCISR1 & SCISR1_RDRF_MASK));
  return(SCIDRL);
}

char SCIdequeue(void) {
    char nextConsumed;
    int out = 0;
    while (sciBufCount == 0); // do nothing � nothing to get
		nextConsumed =  buffer[out];
		out = (out + 1) % BUFFER_SIZE;
		DisableInterrupts;
	  sciBufCount--;
    EnableInterrupts;
		/*  consume the item in nextConsumed */
    return(nextConsumed);
}


// SCI interrupt handler
// Only caring about Receiver Full Interrupt Flag, to see if there's information that has been sent to us (bit 5)
// 
// SCI is interrupt #20
interrupt 20 void SCIhandler( void ){
     SCISR1=0;//reset flag register to default  
      if ((SCISR1 &= SCISR1_RDRF_MASK)>0)   //if the RDRF flag is set, Take RX info and save to ring buffer
      {                    // count this interupt -- if counted down to 0, toggle LEDs
          /*  produce an item and put in nextProduced  */
         static int in = 0;
	       while (sciBufCount == BUFFER_SIZE); // do nothing � nowhere to put it
	       buffer [in] = getcSCI();
	       in = (in + 1) % BUFFER_SIZE;
	       sciBufCount++;
      }
      
               
      
} // end of SCIhandler()