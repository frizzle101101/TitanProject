#include "myUtils.h"
#include "derivative.h"      /* derivative-specific definitions */

void ms_timer_init(void);
void Delay_ms( int k );