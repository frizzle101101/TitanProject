#include "timer.h"

void ms_timer_init(void) 
{
  
  TSCR1 	= 0x90;  		/* enable timer counter, enable fast flag clear*/
	TSCR2 	= 0x82; 		/* enable TCNT overflow interrupt, set prescaler to 64 */
	
	//initilize encoder timer chanels
	CLR_BITS(TIOS,(TIOS_IOS0_MASK|TIOS_IOS1_MASK)); 	/* enable input-capture 0,1 by clearing the bit */
	TCTL4 	= 0x0A; 		/* capture the falling edge of the PT0, and PT1 pin */
	TFLG1 	= 0x03;			/* clear the C0F,C1F flag � in case anything pending */
  TIE = 0x03;         /* enable intrupts for timer 0,1*/
}
void Delay_ms( int k )
{
   	int ix;			/* counter for number of ms delayed */

 	TC6 	= TC6 + 4000;		/* preset TC6 for first OC event */
	TIOS   |= TIOS_IOS6_MASK;	/* ready to go - enable TC6 as OC */

	for (ix = 0; ix < k; ix++) {	/* for number of ms to delay� */
		while(!(TFLG1 & TFLG1_C6F_MASK));	/* wait for OC event */
          	TC6 += 4000;		/* rearm the OC register, this clears TFLG1 */
   	}

   	TIOS  &= ~TIOS_IOS6_MASK;  	/* all done � turn-off OC on TC6 */
}
